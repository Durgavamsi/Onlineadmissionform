from django.db import models



# Create your models here.
class admission(models.Model):
	FName=models.CharField(max_length=30)
	LName=models.CharField(max_length=30)
	FatherName=models.CharField(max_length=30)
	MotherName=models.CharField(max_length=30)
	PNo=models.IntegerField(default=0)
	alternatenumber=models.IntegerField(default=0)
	Email=models.CharField(max_length=50)
	gpa=models.IntegerField(default=0)
	Igpa=models.IntegerField(default=0)
	religion=models.CharField(max_length=30)
	Gender=models.CharField(max_length=30)
	Dateofbirth=models.CharField(max_length=30)
	Present_Address=models.CharField(max_length=400)
	Permanant_Address=models.CharField(max_length=400)
	State=models.CharField(max_length=30)
	District=models.CharField(max_length=30)
	school=models.CharField(max_length=200)
	college=models.CharField(max_length=200)
