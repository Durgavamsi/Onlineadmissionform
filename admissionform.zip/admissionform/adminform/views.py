from django.shortcuts import render,redirect
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from adminform.forms import UsersignupForm
from .forms import TakeadmissionForm
from .models import admission


def home(request):
    return render(request,'adminform/home.html',{})


def signup(request):
    if request.method=="POST":
        form=UsersignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('signin')
    form=UsersignupForm()
    return render(request,'adminform/signup.html',{'form':form})



def admission(request):
	if(request.method=="POST"):
		a=TakeadmissionForm(request.POST)
		if a.is_valid():
			a.save()
			return redirect('home')
	a=TakeadmissionForm()
	return render(request,'adminform/admission.html',{'a':a})	



	