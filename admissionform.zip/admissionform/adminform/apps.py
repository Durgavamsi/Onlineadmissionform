from django.apps import AppConfig


class AdminformConfig(AppConfig):
    name = 'adminform'
