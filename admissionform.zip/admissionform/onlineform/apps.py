from django.apps import AppConfig


class OnlineformConfig(AppConfig):
    name = 'onlineform'
