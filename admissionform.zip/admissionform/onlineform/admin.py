from django.contrib import admin

# Register your models here.

from onlineform.models import Admission

class AdmissionAdmin(admin.ModelAdmin):
    list_display=['FirstName','LastName','FatherName','MotherName','PhoneNumber','District','state','GPATenth','GPAInt','Hostel','Transport','Address','Branch']

admin.site.register(Admission,AdmissionAdmin) 
