from django.db import models

# Create your models here.
class Admission(models.Model):
    FirstName=models.CharField(max_length=30)
    LastName=models.CharField(max_length=30)
    FatherName=models.CharField(max_length=40)
    MotherName=models.CharField(max_length=40)
    PhoneNumber=models.IntegerField(default=0)
    # email = models.EmailField(max_length=256)
    District=models.CharField(max_length=30)
    state=models.CharField(max_length=30)
    GPATenth=models.FloatField(default=0)
    GPAInt=models.FloatField(default=0)
    Hostel=models.CharField(max_length=10)
    Transport=models.CharField(max_length=10)
    Address=models.CharField(max_length=100)
    Branch=models.CharField(max_length=10)